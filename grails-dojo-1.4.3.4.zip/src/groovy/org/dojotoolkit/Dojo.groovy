package org.dojotoolkit

class Dojo {
  static version = "1.4.3"
  static srcHref = "http://download.dojotoolkit.org/release-1.4.3/dojo-release-1.4.3-src.zip"
  static releaseHref = "http://download.dojotoolkit.org/release-1.4.3/dojo-release-1.4.3.zip"
}
